package aula03;

public class aloMundo {

	public static void main(String[] args) {
		System.out.print("Alo, Mundo!");

	}

}
